# WishBridge v0.1
Voluntary social game: People help people thinking they are just playing.