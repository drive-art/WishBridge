// App.js
import React from "react";

function App() {
  return (
    <div>
      <h1>WishBridge v0.1</h1>
      <p>Voluntary social game: People help people thinking they are just playing.</p>
    </div>
  );
}

export default App;